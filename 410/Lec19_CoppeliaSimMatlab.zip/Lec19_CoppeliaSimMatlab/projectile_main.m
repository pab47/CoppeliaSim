% Make sure to have the server side running in CoppeliaSim: 
% in a child script of a CoppeliaSim scene, add following command
% to be executed just once, at simulation start:
%
% simRemoteApi.start(19999)
%
% then start simulation, and run this program.
%
% IMPORTANT: for each successful call to simxStart, there
% should be a corresponding call to simxFinish at the end!

sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
sim.simxFinish(-1); % just in case, close all opened connections
clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);
sim.simxStartSimulation(clientID,sim.simx_opmode_oneshot);

tstart = tic;
total = 4;
if (clientID>-1)
      disp('Connected to remote API server');
      %%%% put MATLAB code here in a loop %%%%%%%%%
      %%% e.g., while(1) ... end %%%
      [returnCode0,sphere]=sim.simxGetObjectHandle(clientID,'Sphere',sim.simx_opmode_blocking);
      sim.simxPauseCommunication(clientID,1);
      returnCode1=sim.simxSetArrayParameter(clientID,sim.sim_arrayparam_gravity,[0 0 -9.81],sim.simx_opmode_oneshot);
      returnCode3a=sim.simxSetObjectFloatParameter(clientID,sphere,3000,1,sim.simx_opmode_oneshot);
      returnCode3b=sim.simxSetObjectFloatParameter(clientID,sphere,3001,0,sim.simx_opmode_oneshot);
      returnCode3c=sim.simxSetObjectFloatParameter(clientID,sphere,3002,5,sim.simx_opmode_oneshot);
      sim.simxPauseCommunication(clientID,0);
      [returnCode2,outInts,outFloats,outStrings,outBuffer]=sim.simxCallScriptFunction(clientID,'Sphere',sim.sim_scripttype_childscript,'User_resetDynamicObject',[],[],[],[],sim.simx_opmode_blocking);
      [returnCode4,linearVelocity,angularVelocity]=sim.simxGetObjectVelocity(clientID,sphere,sim.simx_opmode_streaming);
      while(1)
          [returnCode4,linearVelocity,angularVelocity]=sim.simxGetObjectVelocity(clientID,sphere,sim.simx_opmode_buffer);
          vx = linearVelocity(1);
          vy = linearVelocity(2);
          vz = linearVelocity(3);
           c = 0.25;
            v = sqrt(vx^2+vy^2+vz^2);
            Fx = -c*vx*v;
            Fy = -c*vy*v;
            Fz = -c*vz*v;
            force = [Fx Fy Fz];
            torque = [0,0,0];
            inFloats = [force torque];
            [returnCode5,outInts,outFloats,outStrings,outBuffer]=sim.simxCallScriptFunction(clientID,'Sphere',sim.sim_scripttype_childscript,'User_addForceTorque',[],inFloats,[],[],sim.simx_opmode_blocking);
          if (toc(tstart)>total)
                break;
          end
      end
else
     disp('Failed connecting to remote API server');
end
 
returnCode=sim.simxSetArrayParameter(clientID,sim.sim_arrayparam_gravity,[0 0 0],sim.simx_opmode_oneshot);
      
sim.delete(); % call the destructor!
       
disp('Program ended');


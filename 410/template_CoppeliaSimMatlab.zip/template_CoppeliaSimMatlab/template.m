% Make sure to have the server side running in CoppeliaSim: 
% in a child script of a CoppeliaSim scene, add following command
% to be executed just once, at simulation start:
%
% simRemoteApi.start(19999)
%
% then start simulation, and run this program.
%
% IMPORTANT: for each successful call to simxStart, there
% should be a corresponding call to simxFinish at the end!

sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
sim.simxFinish(-1); % just in case, close all opened connections
clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);
sim.simxStartSimulation(clientID,sim.simx_opmode_oneshot);

if (clientID>-1)
      disp('Connected to remote API server');
      %%%% put MATLAB code here in a loop %%%%%%%%%
      %%% e.g., while(1) ... end %%%
      
else
     disp('Failed connecting to remote API server');
end
  
sim.delete(); % call the destructor!
       
disp('Program ended');

